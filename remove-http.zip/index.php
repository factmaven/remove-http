<?php
/**
> 【=◈︿◈=】
> IS ANYONE THERE?
> OH -
> HI!
*/